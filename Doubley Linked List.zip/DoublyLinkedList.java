import java.util.Scanner;
public class DoublyLinkedList {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        LinkedList list = new LinkedList(); 
        System.out.println("Doubly Linked List Test\n");          
        char ch;
        int choice;
        
        do
        {
            System.out.println("\nDoubly Linked List Operations\n");
            System.out.println("1.Insert\n2.Delete\n3.Show\n4.Exit");
            System.out.print("\nEnter Your Choice: ");
            choice = scan.nextInt();            
            switch (choice)
            {
            case 1 :
                System.out.println("A.Insert at Begining\nB.Insert at End\nC.Insert at Specific Position");
                System.out.print("\nEnter Option:");
                char ob=scan.next().charAt(0);
                if(ob=='A'||ob=='a'){
                System.out.println("Enter integer element to insert");
                list.insertAtStart( scan.nextInt() );                     
                }
                else if(ob=='B'||ob=='b'){ 
                System.out.println("Enter integer element to insert");
                list.insertAtEnd( scan.nextInt() );                     
                }                         
                else if(ob=='C'||ob=='c'){ 
                System.out.println("Enter integer element to insert");
                int num = scan.nextInt() ;
                System.out.println("Enter position");
                int pos = scan.nextInt() ;
                if (pos < 1 || pos > list.getSize() )
                    System.out.println("Invalid position\n");
                else
                    list.insertAtPos(num, pos);
                }
            break;
            case 2 : 
                System.out.println("Enter position");
                int p = scan.nextInt() ;
                if (p < 1 || p > list.getSize() )
                    System.out.println("Invalid position\n");
                else
                    list.deleteAtPos(p);
                break;     
            case 3 : 
                list.display();
                break;           
            default : 
                break;   
            }     
        } while (choice == 1|| choice == 2||choice==3);               
    }
}
