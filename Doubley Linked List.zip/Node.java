public class Node {
    protected int data;
    protected Node next, prev;
    
     public Node()
     {
        next = null;
        prev = null;
        data = 0;
     }
    
     public Node(int d, Node n, Node p)
     {
        data = d;
        next = n;
        prev = p;
     }
     
     public void setLinkNext(Node next)
     {
        this.next = next;
     }
     
     public void setLinkPrev(Node prev)
     {
        this.prev = prev;
     }
     
     public Node getLinkNext()
     {
        return next;
     }
     
     public Node getLinkPrev()
     {
        return prev;
     }
     
     public void setData(int d)
     {
        data = d;
     }
     
     public int getData()
    {
        return data;
    }
}
