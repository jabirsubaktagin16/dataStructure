import java.util.Scanner;
public class Search {
    Node GetNewNode(int data){

        Node  newNode = new Node(data);
        newNode.key = data;
        newNode.left= newNode.right=null;
        return newNode;

    }

    public Node Insert(Node root,int data){
       if(root==null){
           root = GetNewNode(data);
           return root;
       }
       else if(data<= root.key){
           root.left = Insert(root.left,data);
       }
       else{
           root.right= Insert(root.right,data);
       }
       return root;

   }
    public boolean Search(Node root,int data){
       if(root == null)
        return false;
       else if(root.key==data) 
           return true;
       else if(data<= root.key) 
           return Search(root.left,data);
       else 
           return Search(root.right,data);

    }

    public static void main(String[] args) {
        Search tree =new Search();
        Scanner sc=new Scanner(System.in);
        Node root = null;
        root = tree.Insert(root,15);
        root = tree.Insert(root,10);
        root = tree.Insert(root,20);
        root = tree.Insert(root,25);
        root = tree.Insert(root,8);
        root = tree.Insert(root,12);

        int number ;
            System.out.println("Enter number be searched : ");
            number=sc.nextInt();
        if(tree.Search(root,number)==true)
            System.out.println("Found");
        else
                System.out.println("Not Found");   
        }
}
