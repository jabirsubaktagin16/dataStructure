import java.util.Scanner;
public class CompleteBinaryTree {
    public static Node insertNode(int ar[], Node root, int i, int n) {
		
		if (i < n) {
			Node temp = new Node (ar[i]);
			root = temp;
			temp.parent = root;
			
			root.left   =   insertNode(ar, root.left, 2 * i + 1, n);
			root.right  =   insertNode(ar, root.right, 2 * i + 2, n);
		}
		
		return root;
	}
    public static void preOrder(Node root) {
		if (root != null) {
			System.out.print(root.key + " ");
			preOrder(root.left);
			preOrder(root.right);
		}
	}
	public static void postOrder(Node root) {
		if (root != null) {
			preOrder(root.left);
			preOrder(root.right);
			System.out.print(root.key + " ");
		}
	}
	public static void inOrder(Node root) {
		if (root != null) {
			preOrder(root.left);
			System.out.print(root.key + " ");
			preOrder(root.right);
		}
	}
        public static void main(String[] args) {
		int arr[] = new int[100];
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		for (int i = 0; i < n; i++)
			arr[i] = sc.nextInt();
		
		Node root = null;
		root = insertNode(arr, root, 0, n);
		
		preOrder(root);
	}
}
