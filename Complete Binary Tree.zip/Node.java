public class Node {
    int key;
	Node left, right, parent;
	
	Node(int value){
		key = value;
	}
	
}

