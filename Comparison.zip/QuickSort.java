import java.util.Random;
import java.util.concurrent.TimeUnit;
public class QuickSort {
    public static long time;
    public static int comparison;
    public static int pass;
void quick_sort(int arr[], int f, int l)
{
    long starttime=System.nanoTime();
    if(f>=l)
        return;
    int i, j;
    i=f+1;
    while(arr[i]<arr[f]){
        i++;
        if (i>19999)break;
        comparison++;
    }
    j=l;
    while(arr[j]>arr[f]){
        j--;
        comparison++;
    }
    while(i<j)
    {
        arr[i]=arr[j];
        pass++;
        do
        {
            i++;
            if (i>19999)break;
            comparison++;
        } while(arr[i]<arr[f]);
        do
        {
            j--;
            comparison++;
        } while(arr[j]>arr[f]);
    }
    arr[f]=arr[j];
    swap(arr[f],arr[l]);
    pass++;
    quick_sort(arr, f, j-1);
    quick_sort(arr, j+1, l);
    long endtime=System.nanoTime();
    time=endtime-starttime;
}
    private void swap(int a, int b) {
            int temp = a;
            a = b;
            b = temp;
    }
 }