
import java.util.Random;

public class Comparison {
    public static void main(String[] args) {
        Random rand = new Random();
         BubbleSort bs =new BubbleSort();
         InsertionSort is =new InsertionSort();
         QuickSort qs = new QuickSort();
         SelectionSort ss = new SelectionSort();
         MergeSort ms = new MergeSort();
        int arr[] = new int[20000];
        
        for(int i=0 ; i<20000 ; i++)
            arr[i] = rand.nextInt((75)+1);
   
        bs.bubble(arr);
        is.insertion(arr);
        ss.selection(arr);
        qs.quick_sort(arr, 0, 19999);
        ms.MergeSort(arr, 0, 19999);
        System.out.println("\t\tBubble Sort\tInsertion Sort\tSelection Sort\tQuick Sort\tMerge Sort");
        System.out.println("Comparison\t" +bs.comparison+"\t" +is.comparison+"\t\t"+ss.comparison+"\t"+qs.comparison+"\t\t"+ms.comparison);
        System.out.println("Movement\t"+bs.pass+"\t"+is.pass+"\t"+ss.pass+"\t\t"+qs.pass+"\t\t"+ms.pass);
        System.out.println("Time\t\t"+bs.time+"\t"+is.time+"\t"+ss.time+"\t"+qs.time+"\t"+ms.time);
}
}
