//import java.util.Random;
import java.util.concurrent.TimeUnit;
public class BubbleSort {
    
    public static long time;
    public static int comparison;
    public static int pass;

    void bubble(int arr[]){
        
        long startTime = System.nanoTime();
        int n=20000, k, t=0, temp;
        k = n;
        while(k != 0){
            t=0;
            for(int j=0 ; j<k-1 ; j++){
                comparison ++;
                if(arr[j] > arr[j+1]){
                    temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                    pass += 3;
                    t = j;
                }
            }
            k = t;
        }
        long endTime = System.nanoTime();
        time = endTime - startTime;
    }
}