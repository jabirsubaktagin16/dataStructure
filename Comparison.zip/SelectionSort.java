import java.util.concurrent.TimeUnit;
public class SelectionSort {
    public static long time;
    public static int comparison;
    public static int pass;
    
    void selection(int arr[]){
        long startTime = System.nanoTime();
        int n=20000,k,t=0,temp;
        for(int j=n-1; j>=1; j--){
            t=0;
            for(k=1; k<=j; k++){
            comparison++;
            if(arr[t]<arr[k])
                t=k;
            }
            temp = arr[t];
            arr[t] = arr[j];
            arr[j] = temp;
            pass+= 3;
        }
        long endTime = System.nanoTime();
        time = endTime - startTime;
    }
}
