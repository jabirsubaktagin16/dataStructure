//import java.util.Random;
import java.util.concurrent.TimeUnit;
public class InsertionSort {
    public static int time;
    public static int comparison;
    public static int pass;
    void insertion(int array[]) {
        long startTime = System.nanoTime();
        int n = 20000;
        for (int j = 1; j < n; j++) {  
            int t = array[j];  
            int i = j-1;
            comparison++;
            while ((i > -1) && ( array [i] > t ) ) {  
                array [i+1] = array [i];
                pass++;
                i--;  
            }  
            array[i+1] = t; 
            pass+=2;
        }  
         long endTime = System.nanoTime();
        time =(int) (endTime - startTime);
    }  
       
}
