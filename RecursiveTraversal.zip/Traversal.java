 import java.util.Scanner;
 import java.util.Stack;
 public class Traversal
 {
     Scanner sc= new Scanner(System.in);
     public Node insert(){
        Node tree= new Node();
        
        System.out.println("Enter the value");
        tree.data=sc.nextInt();
        System.out.println("Enetr y if "+tree.data+" has left sub-tree: ");
        if(sc.next().charAt(0)== 'y')
            tree.left=insert();
        else
            tree.left= null;
        System.out.println("Enetr y if "+tree.data+" has right sub-tree: ");
        if(sc.next().charAt(0)== 'y')
            tree.right=insert();
        else
            tree.right= null;
        
        return tree;
    }
    public void preorder(Node root){
        if(root==null)
            return;
        System.out.print(root.data+" ");
        
        preorder(root.left);
        preorder(root.right);
    }
    public void inorder(Node root){
        if(root==null)
            return;
        
        inorder(root.left);
        System.out.print(root.data+" ");
        inorder(root.right);
        
    }
    public void postorder(Node root){
        if(root==null)
            return;
        
        postorder(root.left);
        postorder(root.right);
        System.out.print(root.data+" ");
    }
    public void preorder2(Node root){
    if(root==null)
        return;
    Stack<Node> stack=new Stack();

    while(true){
        while(root!=null){
            System.out.print(root);
            stack.push(root);
            root=root.left;
        }
        if(stack.isEmpty())break;
        root=stack.pop();
        root=root.right;
        }
    }
    public static Stack<Node> s1, s2;
     
       public static void postOrderIterative(Node root) 
        {
        s1 = new Stack<>();
        s2 = new Stack<>();
 
        if (root == null)
            return;
 
        s1.push(root);
         
        while (!s1.isEmpty()) 
        {
            Node tree = s1.pop();
            s2.push(tree);
         
            if (tree.left != null)
                s1.push(tree.left);
            if (tree.right != null)
                s1.push(tree.right);
        }
        while (!s2.isEmpty()) 
        {
            Node temp = s2.pop();
            System.out.print(temp.data + " ");
        }
    }
       public static void iterativePreorder(Node root) {
         
        if (root == null) {
            return;
        }
 
        Stack<Node> nodeStack = new Stack();
        nodeStack.push(root);
 
        while (nodeStack.empty() == false) {
             
            Node mynode = nodeStack.peek();
            System.out.print(mynode.data + " ");
            nodeStack.pop();
            if (mynode.right != null) {
                nodeStack.push(mynode.right);
            }
            if (mynode.left != null) {
                nodeStack.push(mynode.left);
            }
        }
     }
       public static void iterativeInorder(Node root) {
        if (root == null) {
            return;
        }
        
        Stack<Node> stack = new Stack();
        Node node = root;
         
        while (node != null) {
            stack.push(node);
            node = node.left;
        }
         
        while (stack.size() > 0) {
           
            node = stack.pop();
            System.out.print(node.data + " ");
            if (node.right != null) {
                node = node.right;
                 
                while (node != null) {
                    stack.push(node);
                    node = node.left;
                }
            }
        }
    }
    public static void main(String args[]){
        
        Traversal t= new Traversal();
        Node root= new Node();
        root=t.insert();
           
        System.out.println("Preorder traversal of binary tree is: ");
        t.preorder(root);
        System.out.println(" ");
        System.out.println("Inorder traversal of binary tree is: ");
        t.inorder(root);
        System.out.println(" ");
        System.out.println("Postorder traversal of binary tree is: ");
        t.postorder(root);
      
        System.out.println("Non Recursive Post Order: ");
        t.postOrderIterative(root); 
        System.out.println(" ");
        
        System.out.println("Non Recursive Pre Order: ");
        t.iterativePreorder(root);
        System.out.println(" ");
        
        System.out.println("Non Recursive In Order: ");
        t.iterativeInorder(root);
        System.out.println(" ");
        
    }
 }