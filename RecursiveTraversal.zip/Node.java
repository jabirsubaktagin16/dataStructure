public class Node        
 {
     int data;
    Node head ,left, right;
    
    public Node(){
        data=0;
        left = null; 
        right = null;
    }         
 }
