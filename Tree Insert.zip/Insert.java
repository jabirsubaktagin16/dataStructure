
import java.util.Scanner;

public class Insert {

    public Node root;
    public static int sum1;
    public static int sum2;
    public static int minus;
    public Insert() {
        root = null;
    }

    public void insert(int key) {
        root = insertRec(root, key);
    }

    Node insertRec(Node root, int key) {

        if (root == null) {
            root = new Node(key);
            return root;
        }

        if (key < root.key) {
            root.left = insertRec(root.left, key);
            sum1 += root.left.key;
        } else if (key > root.key) {
            root.right = insertRec(root.right, key);
            sum2 += root.right.key;
        }
        return root;
    }

    public void inorder() {
        inorderRec(root);
    }

    public void inorderRec(Node root) {
        if (root != null) {
            inorderRec(root.left);
            System.out.println(root.key);
            inorderRec(root.right);
        }
    }

    public static void main(String[] args) {
        Insert tree = new Insert();
        
        tree.insert(50);
        tree.insert(30);
        tree.insert(20);
        tree.insert(40);
        tree.insert(70);
        tree.insert(60);
        tree.insert(80);

        tree.inorder();
        System.out.println("Sum of Left Child:" + sum1);
        System.out.println("Sum of Right Child:" + sum2);
        minus=sum1-sum2;
        System.out.println("The substractor result is: " +minus);
    }
}
